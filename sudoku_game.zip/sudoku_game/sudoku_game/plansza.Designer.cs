﻿namespace sudoku_game
{
    partial class plansza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox0 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox0
            // 
            this.textBox0.Location = new System.Drawing.Point(21, 108);
            this.textBox0.MaxLength = 1;
            this.textBox0.Name = "textBox0";
            this.textBox0.Size = new System.Drawing.Size(18, 20);
            this.textBox0.TabIndex = 1;
            this.textBox0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(45, 108);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(18, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(69, 108);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(18, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(97, 108);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(18, 20);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(121, 108);
            this.textBox4.MaxLength = 1;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(18, 20);
            this.textBox4.TabIndex = 2;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(145, 108);
            this.textBox5.MaxLength = 1;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(18, 20);
            this.textBox5.TabIndex = 3;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(175, 108);
            this.textBox6.MaxLength = 1;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(18, 20);
            this.textBox6.TabIndex = 1;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(199, 108);
            this.textBox7.MaxLength = 1;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(18, 20);
            this.textBox7.TabIndex = 2;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(223, 108);
            this.textBox8.MaxLength = 1;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(18, 20);
            this.textBox8.TabIndex = 3;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(21, 134);
            this.textBox10.MaxLength = 1;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(18, 20);
            this.textBox10.TabIndex = 4;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(45, 134);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(18, 20);
            this.textBox11.TabIndex = 5;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(69, 134);
            this.textBox12.MaxLength = 1;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(18, 20);
            this.textBox12.TabIndex = 6;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(97, 134);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(18, 20);
            this.textBox13.TabIndex = 4;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(121, 134);
            this.textBox14.MaxLength = 1;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(18, 20);
            this.textBox14.TabIndex = 4;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(145, 134);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(18, 20);
            this.textBox15.TabIndex = 5;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(175, 134);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(18, 20);
            this.textBox16.TabIndex = 4;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox16.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(199, 134);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(18, 20);
            this.textBox17.TabIndex = 5;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox17.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(223, 134);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(18, 20);
            this.textBox18.TabIndex = 6;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox18.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(21, 160);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(18, 20);
            this.textBox20.TabIndex = 7;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox20.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(45, 160);
            this.textBox21.MaxLength = 1;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(18, 20);
            this.textBox21.TabIndex = 8;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox21.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(69, 160);
            this.textBox22.MaxLength = 1;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(18, 20);
            this.textBox22.TabIndex = 9;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox22.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(97, 160);
            this.textBox23.MaxLength = 1;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(18, 20);
            this.textBox23.TabIndex = 7;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox23.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(121, 160);
            this.textBox24.MaxLength = 1;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(18, 20);
            this.textBox24.TabIndex = 8;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox24.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(145, 160);
            this.textBox25.MaxLength = 1;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(18, 20);
            this.textBox25.TabIndex = 9;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox25.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(175, 160);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(18, 20);
            this.textBox26.TabIndex = 7;
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox26.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(199, 160);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(18, 20);
            this.textBox27.TabIndex = 8;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox27.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(223, 160);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(18, 20);
            this.textBox28.TabIndex = 9;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox28.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(21, 195);
            this.textBox30.MaxLength = 1;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(18, 20);
            this.textBox30.TabIndex = 1;
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox30.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(45, 195);
            this.textBox31.MaxLength = 1;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(18, 20);
            this.textBox31.TabIndex = 2;
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox31.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(69, 195);
            this.textBox32.MaxLength = 1;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(18, 20);
            this.textBox32.TabIndex = 3;
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox32.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(97, 195);
            this.textBox33.MaxLength = 1;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(18, 20);
            this.textBox33.TabIndex = 1;
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox33.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(121, 195);
            this.textBox34.MaxLength = 1;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(18, 20);
            this.textBox34.TabIndex = 2;
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox34.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(145, 195);
            this.textBox35.MaxLength = 1;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(18, 20);
            this.textBox35.TabIndex = 3;
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox35.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(175, 195);
            this.textBox36.MaxLength = 1;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(18, 20);
            this.textBox36.TabIndex = 1;
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox36.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(199, 195);
            this.textBox37.MaxLength = 1;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(18, 20);
            this.textBox37.TabIndex = 2;
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox37.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(223, 195);
            this.textBox38.MaxLength = 1;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(18, 20);
            this.textBox38.TabIndex = 3;
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox38.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(21, 221);
            this.textBox40.MaxLength = 1;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(18, 20);
            this.textBox40.TabIndex = 4;
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox40.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(45, 221);
            this.textBox41.MaxLength = 1;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(18, 20);
            this.textBox41.TabIndex = 5;
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox41.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(69, 221);
            this.textBox42.MaxLength = 1;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(18, 20);
            this.textBox42.TabIndex = 6;
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox42.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(97, 221);
            this.textBox43.MaxLength = 1;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(18, 20);
            this.textBox43.TabIndex = 4;
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox43.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(121, 221);
            this.textBox44.MaxLength = 1;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(18, 20);
            this.textBox44.TabIndex = 5;
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox44.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(145, 221);
            this.textBox45.MaxLength = 1;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(18, 20);
            this.textBox45.TabIndex = 6;
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox45.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(175, 221);
            this.textBox46.MaxLength = 1;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(18, 20);
            this.textBox46.TabIndex = 4;
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox46.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(199, 221);
            this.textBox47.MaxLength = 1;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(18, 20);
            this.textBox47.TabIndex = 5;
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox47.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(223, 221);
            this.textBox48.MaxLength = 1;
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(18, 20);
            this.textBox48.TabIndex = 6;
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox48.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(21, 247);
            this.textBox50.MaxLength = 1;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(18, 20);
            this.textBox50.TabIndex = 7;
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox50.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(45, 247);
            this.textBox51.MaxLength = 1;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(18, 20);
            this.textBox51.TabIndex = 8;
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox51.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(69, 247);
            this.textBox52.MaxLength = 1;
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(18, 20);
            this.textBox52.TabIndex = 9;
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox52.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(97, 247);
            this.textBox53.MaxLength = 1;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(18, 20);
            this.textBox53.TabIndex = 7;
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox53.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(121, 247);
            this.textBox54.MaxLength = 1;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(18, 20);
            this.textBox54.TabIndex = 8;
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox54.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(145, 247);
            this.textBox55.MaxLength = 1;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(18, 20);
            this.textBox55.TabIndex = 9;
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox55.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(175, 247);
            this.textBox56.MaxLength = 1;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(18, 20);
            this.textBox56.TabIndex = 7;
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox56.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(199, 247);
            this.textBox57.MaxLength = 1;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(18, 20);
            this.textBox57.TabIndex = 8;
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox57.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(223, 247);
            this.textBox58.MaxLength = 1;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(18, 20);
            this.textBox58.TabIndex = 9;
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox58.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(21, 285);
            this.textBox60.MaxLength = 1;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(18, 20);
            this.textBox60.TabIndex = 1;
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox60.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(45, 285);
            this.textBox61.MaxLength = 1;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(18, 20);
            this.textBox61.TabIndex = 2;
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox61.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(69, 285);
            this.textBox62.MaxLength = 1;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(18, 20);
            this.textBox62.TabIndex = 3;
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox62.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(97, 285);
            this.textBox63.MaxLength = 1;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(18, 20);
            this.textBox63.TabIndex = 1;
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox63.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(121, 285);
            this.textBox64.MaxLength = 1;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(18, 20);
            this.textBox64.TabIndex = 2;
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox64.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(145, 285);
            this.textBox65.MaxLength = 1;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(18, 20);
            this.textBox65.TabIndex = 3;
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox65.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(175, 285);
            this.textBox66.MaxLength = 1;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(18, 20);
            this.textBox66.TabIndex = 1;
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox66.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(199, 285);
            this.textBox67.MaxLength = 1;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(18, 20);
            this.textBox67.TabIndex = 2;
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox67.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(223, 285);
            this.textBox68.MaxLength = 1;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(18, 20);
            this.textBox68.TabIndex = 3;
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox68.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(21, 311);
            this.textBox70.MaxLength = 1;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(18, 20);
            this.textBox70.TabIndex = 4;
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox70.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(45, 311);
            this.textBox71.MaxLength = 1;
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(18, 20);
            this.textBox71.TabIndex = 5;
            this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox71.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(69, 311);
            this.textBox72.MaxLength = 1;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(18, 20);
            this.textBox72.TabIndex = 6;
            this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox72.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(97, 311);
            this.textBox73.MaxLength = 1;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(18, 20);
            this.textBox73.TabIndex = 4;
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox73.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(121, 311);
            this.textBox74.MaxLength = 1;
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(18, 20);
            this.textBox74.TabIndex = 5;
            this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox74.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(145, 311);
            this.textBox75.MaxLength = 1;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(18, 20);
            this.textBox75.TabIndex = 6;
            this.textBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox75.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(175, 311);
            this.textBox76.MaxLength = 1;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(18, 20);
            this.textBox76.TabIndex = 4;
            this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox76.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(199, 311);
            this.textBox77.MaxLength = 1;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(18, 20);
            this.textBox77.TabIndex = 5;
            this.textBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox77.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(223, 311);
            this.textBox78.MaxLength = 1;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(18, 20);
            this.textBox78.TabIndex = 6;
            this.textBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox78.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(21, 337);
            this.textBox80.MaxLength = 1;
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(18, 20);
            this.textBox80.TabIndex = 7;
            this.textBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox80.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(45, 337);
            this.textBox81.MaxLength = 1;
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(18, 20);
            this.textBox81.TabIndex = 8;
            this.textBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox81.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(69, 337);
            this.textBox82.MaxLength = 1;
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(18, 20);
            this.textBox82.TabIndex = 9;
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox82.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(97, 337);
            this.textBox83.MaxLength = 1;
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(18, 20);
            this.textBox83.TabIndex = 7;
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox83.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(121, 337);
            this.textBox84.MaxLength = 1;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(18, 20);
            this.textBox84.TabIndex = 8;
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox84.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(145, 337);
            this.textBox85.MaxLength = 1;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(18, 20);
            this.textBox85.TabIndex = 9;
            this.textBox85.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox85.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(175, 337);
            this.textBox86.MaxLength = 1;
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(18, 20);
            this.textBox86.TabIndex = 7;
            this.textBox86.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox86.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(199, 337);
            this.textBox87.MaxLength = 1;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(18, 20);
            this.textBox87.TabIndex = 8;
            this.textBox87.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox87.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(223, 337);
            this.textBox88.MaxLength = 1;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(18, 20);
            this.textBox88.TabIndex = 9;
            this.textBox88.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox88.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 96);
            this.label1.TabIndex = 89;
            this.label1.Text = "SUDOKU GAME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(40, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 90;
            this.button1.Text = "Sprawdz!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(69, 392);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 23);
            this.button2.TabIndex = 91;
            this.button2.Text = "Zacznij od nowa";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(142, 363);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 92;
            this.button3.Text = "Podpowiedz";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // plansza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 424);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox0);
            this.Name = "plansza";
            this.Text = "t";
            this.Load += new System.EventHandler(this.plansza_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox0;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}