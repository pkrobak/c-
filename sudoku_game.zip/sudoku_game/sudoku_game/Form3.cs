﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace sudoku_game
{
    public partial class Form3 : Form
    {


        public Form3(int czas)
        {
            InitializeComponent();
            label5.Text = czas.ToString();

        }
      

        private void button1_Click(object sender, EventArgs e)
        {
            int czas = Int32.Parse(label5.Text);
            string imie = textBox1.Text;
            this.Visible = false; 
            Form2 tabela = new Form2(czas,imie); 
            tabela.ShowDialog(); 
            this.Close(); 
        }
    }
}
