﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace sudoku_game
{
    public partial class plansza : Form
    {
        public plansza()
        {
            InitializeComponent();
            BoardGenerator();

        }



      
        int[,] wiersz = new int[9, 9];  
        int[,] kolumna = new int[9, 9];
        int[,] kwadrat = new int[9, 9]; 
        string textbox_nr,name;
        Random generator = new Random();
        

        public int[] UniqueArray()
        {
            int[] data = new int[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int temp, x, y;

            for (int i = 0; i <30; i++)
            {
                x = generator.Next(1, 9 );
                y = generator.Next(1, 9 );

                temp = data[x];
                data[x] = data[y];
                data[y] = temp;
            }

            return data;
        }

        public void ReadFields() 
        {
            int ktory_kwadrat;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0) 
                    {
                        name = j.ToString();
                    }
                    else 
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;  
                    if (!string.IsNullOrEmpty(tbx.Text)) 
                    {
                        ktory_kwadrat = whichSquare(i, j);
                        kwadrat[ktory_kwadrat, tbx.TabIndex - 1] = Int32.Parse(tbx.Text);
                        wiersz[i, j] = Int32.Parse(tbx.Text);
                        kolumna[j, i] = Int32.Parse(tbx.Text);
                    }
                    else 
                    {
                        ktory_kwadrat = whichSquare(i, j);
                        kwadrat[ktory_kwadrat, tbx.TabIndex - 1] = 0;
                        wiersz[i, j] = 0;
                        kolumna[j, i] = 0;
                    }

                }
            }
        }
        private int whichSquare(int a, int b) 
        {
            int square_number = 0;

            if (a < 3 && b < 3)
            {
                square_number = 0;
            }
            else if (a < 3 && b > 2 && b < 6)
            {
                square_number = 1;
            }
            else if (a < 3 && b > 5)
            {
                square_number = 2;
            }
            else if (a > 2 && a < 6 && b < 3)
            {
                square_number = 3;
            }
            else if (a > 2 && a < 6 && b > 2 && b < 6)
            {
                square_number = 4;
            }
            else if (a > 2 && a < 6 && b > 5)
            {
                square_number = 5;
            }
            else if (a > 5 && b < 3)
            {
                square_number = 6;
            }
            else if (a > 5 && b > 2 && b < 6)
            {
                square_number = 7;
            }
            else if (a > 5 && b > 5)
            {
                square_number = 8;
            }
            return square_number;
        }
        private void Replace() 
        {
            int ktory_kwadrat;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++) 
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0)
                    {
                        name = j.ToString();
                    }
                    else
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;

                    tbx.Text = wiersz[i, j].ToString();
                    kolumna[j, i] = wiersz[i, j];
                    ktory_kwadrat = whichSquare(i, j);
                    kwadrat[ktory_kwadrat, tbx.TabIndex - 1] = Int32.Parse(tbx.Text);
                }
            }
        }

        private void PermutationSquare(int x, int y, bool z) 
        {
            for (int i = x; i < x + 3; i++) 
            {
                for (int j = y; j < y + 3; j++)
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0)
                    {
                        name = j.ToString();
                    }
                    else
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                    if(z == false) 
                    {
                        if (i < x + 2)
                        { wiersz[i, j] = wiersz[i + 1, j - 3]; } 
                        else 
                        { wiersz[i, j] = wiersz[i - 2, j - 3]; } 
                    }
                    else 
                    {
                        if (j < y + 2) 
                        { wiersz[i, j] = wiersz[i - 3, j + 1]; }
                        else
                        { wiersz[i, j] = wiersz[i - 3, j - 2]; }
                    }
                }

            }
        }
      
      

        private bool IsFilled()
        {
            bool koniec = false;
            int kontrol = 0;

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0)
                    {
                        name = j.ToString();
                    }
                    else
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                    if (!string.IsNullOrEmpty(tbx.Text)) 
                    {
                        kontrol++;
                    }
                    else 
                    {
                        koniec = false;
                        return koniec; 
                    }
                    
                }
            }
            if (kontrol >= 81) 
            {
                koniec = true;
            }
            return koniec;
        }

        private void Clear()
        {
            for(int i = 0; i<9; i++)
            {
                for(int j = 0; j<9; j++) 
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0)
                    {
                        name = j.ToString();
                    }
                    else
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                    tbx.Text = null; 
                    wiersz[i, j] = 0;
                    kolumna[j, i] = 0;
                    kwadrat[i, j] = 0;
                }
            }
        }

        private bool czyDobrze()
        {
            bool czydobrze = false;
            int kontrol_wiersz = 0;
            int kontrol_kolumna = 0;
            int ktory_kwadrat;
            int kontrol_kwadrat = 0;
            
            for(int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++) 
                {
                    for (int k = 0; k < 9; k++)
                    {
                        if (k == j) k++; 
                        else
                        {
                            if ( wiersz [i,j] == wiersz [i,k] ) 
                            {
                                kontrol_wiersz++; 
                                textbox_nr = i.ToString() + j.ToString();
                                if (i == 0)
                                {
                                    name = j.ToString();
                                }
                                else
                                {
                                    name = textbox_nr;
                                }
                                TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                                tbx.BackColor = Color.Red; 
                            }
                        }
                    }                    
                }
            }
            for (int i = 0; i < 9; i++) 
            {
                for (int j = 0; j < 9; j++)
                {
                    for (int k = 0; k < 9; k++)
                    {
                        if (k == i) k++;
                        else
                        {
                            if (kolumna[j, i] == kolumna[j, k])
                            {
                                kontrol_kolumna++;
                                textbox_nr = i.ToString() + j.ToString();
                                if (i == 0)
                                {
                                    name = j.ToString();
                                }
                                else
                                {
                                    name = textbox_nr;
                                }
                                TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                                tbx.BackColor = Color.Red;
                            }
                        }
                    }
                }
            }
            int x, y;
             for (int i = 0; i < 9; i+=3)
             {
                 for (int j = 0; j < 9; j+=3) 
                 {
                    for (int k = 0; k < 3; k++)
                    {
                        for (int l = 0; l < 3; l++)
                        {
                            ktory_kwadrat = whichSquare(i, j);
                            name = whichField(ktory_kwadrat, k, l);
                            TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                            if (!string.IsNullOrEmpty(tbx.Text)) x = Int32.Parse(tbx.Text);
                            else x = 0; ;
                            for (int m = 0; m < 3; m++)
                            {
                                for (int n = 0; n < 3; n++)
                                {
                                    ktory_kwadrat = whichSquare(i, j);
                                    string namee = whichField(ktory_kwadrat, m, n);
                                    TextBox tebx = this.Controls.Find("textBox" + namee, true).FirstOrDefault() as TextBox;
                                    if(name != namee)
                                    {
                                        if (!string.IsNullOrEmpty(tebx.Text)) y = Int32.Parse(tebx.Text);
                                        else y = 0;
                                        if (x == y)
                                        {
                                            kontrol_kwadrat++;
                                            tbx.BackColor = Color.Red;
                                        }
                                    }

                                }

                            }
                        }
                    }
                 }
             }
            if (kontrol_kolumna == 0 && kontrol_wiersz == 0 && kontrol_kwadrat == 0) 
            {
                czydobrze = true;
            }
                    return czydobrze;
        }

        private string whichField(int ktory_kwadrat, int wiersz, int kolumna) 
        {
            int[] array = new int [2]; 
            string name;
            
            
            if (ktory_kwadrat == 0)
            {
                array[0] = wiersz;
                array[1] = kolumna;
            }
            if (ktory_kwadrat == 1)
            {
                array[0] = wiersz;
                array[1] = kolumna+3;
            }
            if (ktory_kwadrat == 2)
            {
                array[0] = wiersz;
                array[1] = kolumna + 6;
            }
            if (ktory_kwadrat == 3)
            {
                array[0] = wiersz + 3;
                array[1] = kolumna;
            }
            if (ktory_kwadrat == 4)
            {
                array[0] = wiersz + 3;
                array[1] = kolumna+3;
            }
            if (ktory_kwadrat == 5)
            {
                array[0] = wiersz + 3;
                array[1] = kolumna+6;
            }
            if (ktory_kwadrat == 6)
            {
                array[0] = wiersz + 6;
                array[1] = kolumna;
            }
            if (ktory_kwadrat == 7)
            {
                array[0] = wiersz + 6;
                array[1] = kolumna + 3;
            }
            if (ktory_kwadrat == 8)
            {
                array[0] = wiersz + 6;
                array[1] = kolumna + 6;
            }
            if (wiersz == 0 && (ktory_kwadrat == 0 || ktory_kwadrat == 1 || ktory_kwadrat == 2))
            {
                name = array[1].ToString();
            }
            else
            {
                name = array[0].ToString() + array[1].ToString();
            }
            return name;
        }

        private void deleteFileds()
        {
            int losuj,ktory_kwadrat;

            losuj = generator.Next(0, 82); 
            if (losuj == 9 || losuj == 19 || losuj == 29 || losuj == 39 || losuj == 49 || losuj == 59 || losuj == 69 || losuj == 79) // poza tymi liczbami bo textboow o takich nr nie ma
            {
                do
                {
                    losuj = generator.Next(0, 82);
                } while (losuj != 9 && losuj != 19 && losuj != 29 && losuj != 39 && losuj != 49 && losuj != 59 && losuj != 69 && losuj != 79);
            }
            else
            {
                name = losuj.ToString();
                TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                tbx.Text = null;
            }
            for (int i = 0; i < 9; i++)  
            {
                for (int j = 0; j < 9; j++)
                {
                    textbox_nr = i.ToString() + j.ToString();
                    if (i == 0)
                    {
                        name = j.ToString();
                    }
                    else
                    {
                        name = textbox_nr;
                    }
                    TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                    if(string.IsNullOrEmpty(tbx.Text)) 
                    {
                        wiersz[i, j] = 0;
                        kolumna[j, i] = 0;
                        ktory_kwadrat = whichSquare(i, j);
                        kwadrat[ktory_kwadrat, tbx.TabIndex - 1] = 0;
                    }
                }
            }
        }

        int[,] WIERSZ = new int[9, 9]; 
        public int podpowiedz;
        private void BoardGenerator()
        {


            czas = 0;
            podpowiedz = 0;
            Clear();
            FillSquares(0, 0);
            ReadFields(); 
            PermutationSquare(0,3,false); 
            PermutationSquare(0, 6,false);
            PermutationSquare(3, 0, true);
            PermutationSquare(3, 3, false);
            PermutationSquare(3, 6, false);
            PermutationSquare(6, 0, true);
            PermutationSquare(6, 3, false);
            PermutationSquare(6, 6, false);
            Replace(); 
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++) 

                    
                {
                    WIERSZ[i,j] = wiersz[i,j]; 
                }
            }
            for(int i = 0; i <60; i++)
            {
                deleteFileds(); 
            }
            
        }

        private void FillSquares(int a, int b) 
        {
            int j;
            int[] array;
            array = UniqueArray();
            for (int i = b; i < b + 9; i++) 
            {
                j = i;
                if (i > b + 2 && i < b + 6) 
                {
                    j = i + 7;
                }
                else if (i > b + 5)
                {
                    j = i + 14;
                }
                TextBox tbx = this.Controls.Find("textBox" + j, true).FirstOrDefault() as TextBox;
                tbx.Text = array[i - b].ToString();
            }
            for (int i = 0; i < 9; i++)
            {
                kwadrat[a, i] = array[i];
            }
        }

        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back )  
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            ReadFields();
            bool czyKoniec = IsFilled();
                bool czydobrze = czyDobrze();
            if (czydobrze == true) 
            {
                this.Visible = false;
                Form3 podajImie = new Form3(czas); 
                podajImie.ShowDialog(); 
                this.Close(); 
                }
                else
                {
                    MessageBox.Show("Blad");
                    for (int i = 0; i < 9; i++)
                    {
                        for (int j = 0; j < 9; j++)
                        {
                            textbox_nr = i.ToString() + j.ToString();
                            if (i == 0)
                            {
                                name = j.ToString();
                            }
                            else
                            {
                                name = textbox_nr;
                            }
                            TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                            tbx.BackColor = Color.White; 
                        }
                    
                }
            }
        }
        public int czas = 0;

        private void timer1_Tick(object sender, EventArgs e)  
        {
            czas++; 
        }

        private void button2_Click(object sender, EventArgs e) 
        {
            BoardGenerator();
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            new Thread(() =>  
            {
                Thread.CurrentThread.IsBackground = true; 
                button3.Enabled = false; 
                podpowiedz++; 
                ReadFields(); 
                if (podpowiedz <= 4) 
                {
                    int x, y;
                    for(int i = 0; i<99999; i++)
                    { 
                        x = generator.Next(0, 9);
                        y = generator.Next(0, 9);

                        if (x == 0)
                        {
                            name = y.ToString();
                        }
                        else
                        {
                            textbox_nr = x.ToString() + y.ToString();
                            name = textbox_nr;
                        }
                        TextBox tbx = this.Controls.Find("textBox" + name, true).FirstOrDefault() as TextBox;
                        if (string.IsNullOrEmpty(tbx.Text))
                        {
                            tbx.Text = WIERSZ[x, y].ToString(); 
                            break; 
                        }
                    }



                    Thread.Sleep(10000); 
                    button3.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Wykorzystales wszystkie podpowiedzi!");
                }
            }).Start(); 
          
        }

        private void plansza_Load(object sender, EventArgs e)
        {

        }
    }
}
