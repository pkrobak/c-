﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace sudoku_game
{
    public partial class Form2 : Form
    {
        public Form2(int czas, string imie)
        {
            InitializeComponent();
            DataSet dsScore = new DataSet(); 

            if (File.Exists("ScoreData.xml"))
            { 
                dsScore.ReadXml("ScoreData.xml");
                DataRow row = dsScore.Tables[0].NewRow();
                row["Name"] = imie; 
                row["Score"] = czas;
                dsScore.Tables[0].Rows.Add(row); 
                dsScore.WriteXml("ScoreData.xml"); 
            }
            else 
            {
                CreateDataSet(); 
                dsScore.ReadXml("ScoreData.xml");
                DataRow row = dsScore.Tables[0].NewRow();
                row["Name"] = imie; 
                row["Score"] = czas;
                dsScore.Tables[0].Rows.Add(row); 
                dsScore.WriteXml("ScoreData.xml"); 
            }

            table(dsScore); 
        }
        private void table(DataSet ds)
        {
            int dlugosc = ds.Tables[0].Rows.Count, temp; 
            int[] time = new int [dlugosc];
            string[] name = new string[dlugosc];
            string temporary;

            ds.ReadXml(("ScoreData.xml"));

            for (int i=0 ; i < ds.Tables[0].Rows.Count/2; i++) 
            {
                name[i] = ds.Tables[0].Rows[i][0].ToString();
                time[i] = Int32.Parse(ds.Tables[0].Rows[i][1].ToString());
            }

            int czyZaminiono = 0; 
            for (int i = 0; i < time.Length * 10; i++)
            {
                int stan = czyZaminiono;
                for ( int j = 0; j < time.Length - 1; j++)
                {
                    if(time[j]>time[j+1])
                    {
                        czyZaminiono++; 
                        temp = time[j];
                        time[j] = time[j + 1]; 
                        time[j + 1] = temp;
                        temporary = name[j];
                        name[j] = name[j + 1];
                        name[j + 1] = temporary;
                    }
                }
                if (stan == czyZaminiono) break; 
            }
            
            for (int i = 0; i < ds.Tables[0].Rows.Count / 2; i++)
            {
                if(time[i] != 0) 
                {
                    ListViewItem item = new ListViewItem(name[i]);
                    item.SubItems.Add(time[i].ToString());
                    listView1.Items.Add(item);
                }
            }


        }
        private void CreateDataSet()
        {
            DataSet dsScore = new DataSet();
            dsScore.DataSetName = "ScoreDataSet";
            dsScore.Tables.Add("Scores");
            dsScore.Tables[0].Columns.Add("Name"); 
            dsScore.Tables[0].Columns.Add("Score", typeof(int));
            
            DataRow row = dsScore.Tables[0].NewRow();
            row["Name"] = "name"; 
            row["Score"] = 0;
            dsScore.Tables[0].Rows.Add(row);

         
            dsScore.WriteXml("ScoreData.xml");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Form1 f1 = new Form1();
            f1.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose(); 
        }
    }
}
